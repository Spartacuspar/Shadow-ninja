# Shadow Ninja

Original side-scrolling ninja platformer (HTML5 canvas) wrapped in an Android WebView.
The game lives in `app/src/main/assets/index.html` and also runs in any browser.

## Get the APK

**Option A – Android Studio:** File > Open this folder, wait for sync, then
Build > Build Bundle(s) / APK(s) > Build APK(s). The file is at
`app/build/outputs/apk/debug/app-debug.apk`.

**Option B – no install (GitHub):** create a GitHub repo, upload this folder, open the
Actions tab > "Build APK" > download the `ShadowNinja-apk` artifact.

Copy the APK to your phone and allow "install unknown apps" when asked.

## Controls
Left/right arrows to move, triangle to jump (tap twice to double-jump),
star to throw shuriken. Stomp guards, avoid spikes, reach the red flag.
Desktop: arrows/WASD, Space to jump, X to throw.
